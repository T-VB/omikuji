package com.dojo.omikuji.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
	//GetMapping same as RequestMapping
	@GetMapping("/")
	public String index() {
		return "redirect:/omikuji";
	}
	@GetMapping("/omikuji")
	public String omikuji() {
		return "index.jsp";
	}
	@GetMapping("/omikuji/show")
	public String omikujiShow(HttpSession session, Model model) {
		
		//clarify data type will return as a String
		String result = (String) session.getAttribute("omikujiResult");
		model.addAttribute("result", result);
		return "omikujiShow.jsp";
	}
	//@PostMapping for posting form info
	@PostMapping("/formSubmit")
	public String processForm( 
			
		//RequestParam used to send back info through url as key:value pairs 
		@RequestParam("num") int number,
		@RequestParam("city") String city,
		@RequestParam("person") String person,
		@RequestParam("hobby") String hobby,
		@RequestParam("livingThing") String livingThing,
		@RequestParam("message") String message,
		HttpSession session
		) {
		
		//using key:value pairs, you can set certain attributes in to be in session
		session.setAttribute("num", number);
		
		
		String omikujiResult = String.format(
				"In %s years, you will live in %s with %s as your roommate, you enjoy %s as a hobby. The next time you see a %s, you will have good luck. %s.", 
				number, city, person, hobby, livingThing, message); 	
	
		session.setAttribute("omikujiResult", omikujiResult);
		return "redirect:/omikuji/show";
	}
}
